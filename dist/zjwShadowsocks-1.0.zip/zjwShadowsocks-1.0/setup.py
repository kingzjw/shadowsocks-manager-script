#coding:utf-8
from distutils.core import setup
setup(name='zjwShadowsocks',  #打包后的包文件名
      version='1.0',
      description='use for manage the json of the shadowsocks',
      author='Jiawei Zhou',
      author_email='zjwking258@gmail.com',
      url='None',
      py_modules=['ss'],   #与前面的新建文件名一致
)